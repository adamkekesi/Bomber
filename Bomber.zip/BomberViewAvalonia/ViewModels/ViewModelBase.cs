﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace BomberViewAvalonia.ViewModels;

public class ViewModelBase : ObservableObject
{
}
