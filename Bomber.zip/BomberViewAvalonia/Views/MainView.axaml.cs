﻿using Avalonia.Controls;

namespace BomberViewAvalonia.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
    }
}
