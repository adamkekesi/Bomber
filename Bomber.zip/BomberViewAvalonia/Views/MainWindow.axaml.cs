﻿using Avalonia.Controls;

namespace BomberViewAvalonia.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
